<?
  header("Location: /venta/index_alquiler.php");
?>
