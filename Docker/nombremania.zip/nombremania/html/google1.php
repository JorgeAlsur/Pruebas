<?
$expira=time()+(45*24*60*60);   //45 dias de vencimiento de la cookie de afiliado
setcookie("affiliate_id","23",$expira,"/",$SERVER_NAME);
?>
<html>
<header>
<meta http-equiv="refresh" content="0;URL=/home.php">
</header>
<body>
<br>
<br>
<br>
<br>
<br>

</body>
</html>

 
