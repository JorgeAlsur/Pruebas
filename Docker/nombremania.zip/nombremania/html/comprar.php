<?
  header("Location: venta/index.php");
?>
