<?
//programa en php horacio degiorgi
header("location : /clientes/pago/i_factura.php?id=".base64_encode($id."-nm"));
 
?>
