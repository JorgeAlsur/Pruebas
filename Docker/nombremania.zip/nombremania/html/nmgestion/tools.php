<html><head>
<link rel="stylesheet" type="text/css" href="estilo.css">
<meta http-equiv="Content-type" content="text/html; charset=UTF-8">
</head><body>
<?
include "barra.php"; include "basededatos.php"; include "hachelib.php";

?>
<ul><li>Calculo para compra de DNS avanzada
<a href="calculo_pro.php">aqui</a>
</li>

</ul>

