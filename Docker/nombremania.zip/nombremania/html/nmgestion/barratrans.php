<center>
<hr NOSHADE>
<p CLASS=titulo size=+2>Administraci&oacute;n de Nombremania</p>
<P class=titulo>
<a href=index.php> Men� ppal</a>|<a href="trans.php?tarea=consulta">Consulta</a>
|<a href="clientes.php">Clientes</a> |
<a href=/> Home </a></P>
</center>
<hr>