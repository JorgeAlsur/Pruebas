<center>
  <br>
</center>
<center>
  <table width="700" border="0" cellspacing="0" cellpadding="3">
    <tr> 
      <td bgcolor="#FFFFCC" align="center"><font size="2"><b><font size="1" color="#000033">CLIENTES</font></b></font></td>
    </tr>
    <tr> 
      <td align="center" bgcolor="#FFFFFF"><font size="2"><a href="clientes.php?tarea=inactivos"> 
        </a><a href="clientes.php?tarea=alta">Alta Manual</a> | <a href="clientes.php?tarea=inactivos">Consulta 
        inactivos/nuevos</a> | <a href="clientes.php?tarea=ver_todos">Ver todos 
        los clientes</a></font> </td>
    </tr>
  </table>
</center>
<hr width="700">
<p>&nbsp;</p>
