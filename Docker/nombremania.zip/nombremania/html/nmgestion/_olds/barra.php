<center>
 <table width="700" border="0" cellspacing="0" cellpadding="3" class="tabla">
   <tr>
     <td bgcolor="#B0B0B0" align="center" colspan="5"> <fontize="2"><b><font color="#FFFFFF"><a href="http://www.nombremania.com">NOMBREMANIA</a>
       - ZONA DE ADMINISTRACION</font></b></font></td>
   </tr>
   <tr>
     <td align="center" bgcolor="#FFFFFF" colspan="5"><a href="index.php?tipo=ultimos">
       </a> </td>
   </tr>
   <tr bgcolor=#FFCA95>
     <td align="center" >Dominios</td>
     <td align="center" >Operaciones</td>
     <td align="center" >Procesos</td>
     <td align="center" >Enlaces</td>
   </tr>
   <tr>
     <td align="center" bgcolor="#FFFFFF"><a href="index.php?tipo=ultimos">Dominios
       Solicitados</a></td>
     <td align="center" bgcolor="#FFFFFF"><a href="clientes.php">Clientes</a></td>
     <td align="center" bgcolor="#FFFFFF"><a href=ver_cola.php>Ver
       cola de procesamiento</a></td>
     <td align="center" bgcolor="#FFFFFF"><a href="http://dns.nombremania.com">Zoneedit</a>
     </td>
    </tr>
   <tr>
     <td align="center" bgcolor="#FFFFFF"> <a href="consultaoperaciones.php?tipo=ultimos">Operaciones</a></td>
     <td align="center" bgcolor="#FFFFFF"><a href=trans.php?tarea=consulta&amp;buscar=20&amp;que=ultimos&amp;orden=fecha>Transacciones</a>
</td>
     <td align="center" bgcolor="#FFFFFF"><a href=ver_log.php target=otra>Ver
       log de procesamiento</a></td>
     <td align="center" bgcolor="#FFFFFF"><a href="http://resellers.opensrs.net">Opensrs</a>&nbsp;|&nbsp;<a href="http://resellers-test.opensrs.net">Test</a></td>
   </tr>
   <tr>
     <td align="center" bgcolor="#FFFFFF"><a href="ver_regalos.php">Ver regalos</a>

	</td>
     <td align="center" bgcolor="#FFFFFF"><a href="facturas.php">Facturas</a></td>
     <td align="center" bgcolor="#FFFFFF"><a href="/registro/tools">Herramientas</a></td>
     <td align="center" bgcolor="#FFFFFF"><a href="http://manage.opensrs.net">Manage
       Opensrs</a></td>
   </tr>
   <tr>
     <td align="center" bgcolor="#FFFFFF">	<a href="../phplibs/sql/exporta_operaciones.php">Exporta operaciones(stat)</a></td>
     <td align="center" bgcolor="#FFFFFF"><a href="liquidaciones.php">Liquidaciones</a>
		 </td>
     <td align="center" bgcolor="#FFFFFF">&nbsp;</td>
     <td align="center" bgcolor="#FFFFFF"> <a href="http://www.nombremania.com/cgi-bin/whois/whois2.cgi">Whois</a></td>
   </tr>
 </table>
 </center>
<hr width="700">
