<?php
		phpinfo();