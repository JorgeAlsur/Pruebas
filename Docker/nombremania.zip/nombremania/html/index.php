<?
  header("Location: home.php?affiliate_id=$affiliate_id");
  //header("Location: home.php?affiliate_id=208");
?>





