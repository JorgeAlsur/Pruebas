<?
  include $_SERVER['DOCUMENT_ROOT']."/clientes/logueado.php";
?>


