
<?
class CFGmod {
 var $email = "horaciod@alsur.es";
 var $url = "http://nmtest.nombremania.com/email2/";
 var $notifyonrequest = "0";
 var $notifyonverify = "0";
 var $notifyonedit = "0";
 var $notifyondelete = "0";
 var $usepassword = "0";
 var $BatchSize = "20";
 var $TimeDelay = "0";
 var $mail_fromname = "Nombremania.com";
 var $mail_mailer = "mail";
 var $mail_sendmail = "/var/qmail/bin/sendmail -t";
 var $mail_host = "";
 var $mail_port = "25";
 var $mail_timeout = "10";
 var $mail_helo = "";
 var $optSize = "5";
 var $optReq = array("1"=>"o","2"=>"o","3"=>"o","4"=>"o","5"=>"n"  );
 var $optName = array("1"=>"registrado","2"=>"apellido","3"=>"nombre","4"=>"producto","5"=>""  );
 var $optDefault = array("1"=>"0:1","2"=>"","3"=>"","4"=>"","5"=>"" );
 var $optType = array("1"=>"text","2"=>"text","3"=>"text","4"=>"text","5"=>"text" );
}
?>

