
<?
class DBmod {
 var $magic_quotes_runtime = "0";
 var $magic_quotes_gpc = "1";
 var $magic_quotes_sybase = "0";
 var $size = "5";
 var $shift = "1";
 var $sql_type = "mysql";
 var $host = "localhost";
 var $user = "program";
 var $password = "mysql2008";
 var $database = "ciao";
 var $tableprefix = "elm";
}
?>

