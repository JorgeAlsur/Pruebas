<HTML><!-- #BeginTemplate "/Templates/nm2_base.dwt" --><!-- DW6 -->
<HEAD>
<meta http-equiv="Content-type" content="text/html; charset=UTF-8">
<!-- #BeginEditable "doctitle" --> 
<TITLE>NombreMania - Registro y traslado de dominios. Registro de dominios al 
mejor precio. </TITLE>
<!-- #EndEditable --> 
<SCRIPT language="JavaScript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}

function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</SCRIPT>
<meta name="title" content="NombreMania - registro y traslado de dominios - en tus dominios solo mandas tu">
<meta name="description" content="Nunca fue tan facil registrar y trasladar dominios. En NombreMania ofrecemos registro de dominios al mejor precio, en castellano y con las herramientas mas potentes de administraci�n.">
<meta name="keywords" content="registro de dominios, registrar dominios, dominios, traslado, renovar, registro dominios espa�ol, dominios en castellano">
<meta name="language" content="Spanish">
<meta name="author" content="El Sur Existe s.l.">
<meta name="copyright" content="El Sur Existe s.l.">
<meta name="revisit-after" content="30 days">
<meta name="document-classification" content="Internet Services">
<meta name="document-rights" content="unlimited">
<meta name="document-type" content="Public">
<meta name="document-rating" content="General">
<meta name="Abstract" content="Nunca fue tan facil registrar y trasladar dominios. En NombreMania ofrecemos registro de dominios al mejor precio, en castellano y con las herramientas mas potentes de administraci�n.">
<meta name="Target" content="registro de dominios, registrar dominios, dominios, traslado, renovar, registro dominios espa�ol">
<meta http-equiv="Content-Language" content="ES">
<link rel="stylesheet" href="/Templates/nm2_base_registro.css" type="text/css">
</HEAD>
<body bgcolor="#ffcc00" onLoad="MM_preloadImages('/imagenes/base3/simbolo_f2.gif','/imagenes/base3/logo_f2.gif','/imagenes/base3/registrar_f2.gif','/imagenes/base3/trasladar_f2.gif','/imagenes/base3/administrar_f2.gif','/imagenes/base3/comprar_f2.gif','/imagenes/base3/alquiler_f2.gif','/imagenes/base3/demo_f2.gif','/imagenes/base3/precios_f2.gif','/imagenes/base3/afiliados_f2.gif','/imagenes/base3/ayuda_f2.gif','/imagenes/base3/whois_f2.gif')"><!-- #BeginLibraryItem "/Library/nm2_navegador.lbi" --><table border="0" cellpadding="0" cellspacing="0" width="740" align="center">
  <tr> 
    <td><img src="/imagenes/base3/spacer.gif" width="12" height="1" border="0"></td>
    <td><img src="/imagenes/base3/spacer.gif" width="3" height="1" border="0"></td>
    <td><img src="/imagenes/base3/spacer.gif" width="23" height="1" border="0"></td>
    <td><img src="/imagenes/base3/spacer.gif" width="3" height="1" border="0"></td>
    <td><img src="/imagenes/base3/spacer.gif" width="29" height="1" border="0"></td>
    <td><img src="/imagenes/base3/spacer.gif" width="62" height="1" border="0"></td>
    <td><img src="/imagenes/base3/spacer.gif" width="55" height="1" border="0"></td>
    <td><img src="/imagenes/base3/spacer.gif" width="4" height="1" border="0"></td>
    <td><img src="/imagenes/base3/spacer.gif" width="39" height="1" border="0"></td>
    <td><img src="/imagenes/base3/spacer.gif" width="8" height="1" border="0"></td>
    <td><img src="/imagenes/base3/spacer.gif" width="36" height="1" border="0"></td>
    <td><img src="/imagenes/base3/spacer.gif" width="77" height="1" border="0"></td>
    <td><img src="/imagenes/base3/spacer.gif" width="77" height="1" border="0"></td>
    <td><img src="/imagenes/base3/spacer.gif" width="89" height="1" border="0"></td>
    <td><img src="/imagenes/base3/spacer.gif" width="10" height="1" border="0"></td>
    <td><img src="/imagenes/base3/spacer.gif" width="73" height="1" border="0"></td>
    <td><img src="/imagenes/base3/spacer.gif" width="70" height="1" border="0"></td>
    <td><img src="/imagenes/base3/spacer.gif" width="56" height="1" border="0"></td>
    <td><img src="/imagenes/base3/spacer.gif" width="14" height="1" border="0"></td>
    <td><img src="/imagenes/base3/spacer.gif" width="1" height="1" border="0"></td>
  </tr>
  <tr> 
    <td rowspan="2" bgcolor="#ffffff"><img src="/imagenes/base3/cortearriba.gif" width="12" height="14" border="0"></td>
    <td rowspan="5" colspan="2"><img name="simbolo" src="/imagenes/base3/simbolo.gif" width="26" height="42" border="0" alt="registro de dominios"></td>
    <td><img name="corteb_arriba" src="/imagenes/base3/corteb_arriba.gif" width="3" height="5" border="0" alt="registro de dominios"></td>
    <td colspan="3" bgcolor="#ffffff"><img src="/imagenes/base3/corteb_abajo.gif" width="146" height="5" border="0"></td>
    <td rowspan="2"><img name="cortearriba" src="/imagenes/base3/cortearriba.gif" width="4" height="14" border="0" alt="registro de dominios"></td>
    <td rowspan="2" colspan="11" bgcolor="#ffffff"><img src="/imagenes/base3/cortearriba.gif" width="549" height="14" border="0"></td>
    <td><img src="/imagenes/base3/spacer.gif" width="1" height="5" border="0"></td>
  </tr>
  <tr> 
    <td rowspan="3" colspan="4"><a href="/home.php" onMouseOut="MM_swapImgRestore()"  onMouseOver="MM_swapImage('simbolo','','/imagenes/base3/simbolo_f2.gif','logo','','/imagenes/base3/logo_f2.gif',1);" ><img name="logo" src="/imagenes/base3/logo.gif" width="149" height="27" border="0" alt="NombreMania - registro de dominios"></a></td>
    <td><img src="/imagenes/base3/spacer.gif" width="1" height="9" border="0"></td>
  </tr>
  <tr> 
    <td><img name="slice_r3_c1" src="/imagenes/base3/slice_r3_c1.gif" width="12" height="15" border="0" alt="registrar "></td>
    <td><img name="cortemedio" src="/imagenes/base3/cortemedio.gif" width="4" height="15" border="0" alt="registro de dominios"></td>
    <td colspan="3"><img name="slice_r3_c9" src="/imagenes/base3/cortemedio.gif" width="83" height="15" border="0" alt="registro de dominios"></td>
    <td><a href="/registrar.php" onMouseOut="MM_swapImgRestore()"  onMouseOver="MM_swapImage('registrar','','/imagenes/base3/registrar_f2.gif',1);" ><img name="registrar" src="/imagenes/base3/registrar.gif" width="77" height="15" border="0" alt="Registra uno o varios dominios"></a></td>
    <td><a href="/trasladar.php" onMouseOut="MM_swapImgRestore()"  onMouseOver="MM_swapImage('trasladar','','/imagenes/base3/trasladar_f2.gif',1);" ><img name="trasladar" src="/imagenes/base3/trasladar.gif" width="77" height="15" border="0" alt="Traslada tu dominio a NombreMania "></a></td>
    <td><a href="http://admin.nombremania.com" onMouseOut="MM_swapImgRestore()"  onMouseOver="MM_swapImage('administrar','','/imagenes/base3/administrar_f2.gif',1);" ><img name="administrar" src="/imagenes/base3/administrar.gif" width="89" height="15" border="0" alt="Gestiona tus dominios"></a></td>
    <td><img name="slice_r3_c15" src="/imagenes/base3/cortemedio.gif" width="10" height="15" border="0" alt="registro de dominios"></td>
    <td><a href="/comprar.php" onMouseOut="MM_swapImgRestore()"  onMouseOver="MM_swapImage('comprar','','/imagenes/base3/comprar_f2.gif',1);" ><img name="comprar" src="/imagenes/base3/comprar.gif" width="73" height="15" border="0" alt="Dominios en venta"></a></td>
    <td><a href="/alquilar.php" onMouseOut="MM_swapImgRestore()"  onMouseOver="MM_swapImage('alquiler','','/imagenes/base3/alquiler_f2.gif',1);" ><img name="alquiler" src="/imagenes/base3/alquiler.gif" width="70" height="15" border="0" alt="Los dominios también se alquilan"></a></td>
    <td><a href="/demos/" onMouseOut="MM_swapImgRestore()"  onMouseOver="MM_swapImage('demo','','/imagenes/base3/demo_f2.gif',1);" ><img name="demo" src="/imagenes/base3/demo.gif" width="56" height="15" border="0" alt="Demos del sistema"></a></td>
    <td><img name="slice_r3_c19" src="/imagenes/base3/cortemedio.gif" width="14" height="15" border="0" alt="registro de dominios"></td>
    <td><img src="/imagenes/base3/spacer.gif" width="1" height="15" border="0"></td>
  </tr>
  <tr> 
    <td rowspan="2" bgcolor="#ffffff"><img src="/imagenes/base3/corteabajo.gif" width="12" height="13" border="0" alt="dominios"></td>
    <td rowspan="2"><img name="corteabajo" src="/imagenes/base3/corteabajo.gif" width="4" height="13" border="0" alt="registro de dominios"></td>
    <td rowspan="2" colspan="11" bgcolor="#ffffff"><img src="/imagenes/base3/corteabajo.gif" width="549" height="13" border="0"></td>
    <td><img src="/imagenes/base3/spacer.gif" width="1" height="3" border="0"></td>
  </tr>
  <tr> 
    <td><img name="corteb_abajo" src="/imagenes/base3/corteb_abajo.gif" width="3" height="10" border="0" alt="registro de dominios"></td>
    <td colspan="3" bgcolor="#ffffff"><img src="/imagenes/base3/corteb_abajo.gif" width="146" height="10" border="0"></td>
    <td><img src="/imagenes/base3/spacer.gif" width="1" height="10" border="0"></td>
  </tr>
  <tr> 
    <td rowspan="2" bgcolor="#FFFFFF"><img name="iz" src="/imagenes/base3/iz.gif" width="12" height="16" border="0" alt="registro de dominios"></td>
    <td rowspan="2" colspan="4" bgcolor="#FFFFFF"><a href="/precios.php" onMouseOut="MM_swapImgRestore()"  onMouseOver="MM_swapImage('precios','','/imagenes/base3/precios_f2.gif',1);" ><img name="precios" src="/imagenes/base3/precios.gif" width="58" height="16" border="0" alt="Precios y tarifas"></a></td>
    <td rowspan="2" bgcolor="#FFFFFF"><a href="/afiliados.php" onMouseOut="MM_swapImgRestore()"  onMouseOver="MM_swapImage('afiliados','','/imagenes/base3/afiliados_f2.gif',1);" ><img name="afiliados" src="/imagenes/base3/afiliados.gif" width="62" height="16" border="0" alt="Programa de afiliados"></a></td>
    <td rowspan="2" bgcolor="#FFFFFF"><a href="/ayuda/" onMouseOut="MM_swapImgRestore()"  onMouseOver="MM_swapImage('ayuda','','/imagenes/base3/ayuda_f2.gif',1);" ><img name="ayuda" src="/imagenes/base3/ayuda.gif" width="55" height="16" border="0" alt="Ayuda y documentación"></a></td>
    <td rowspan="2" colspan="2" bgcolor="#FFFFFF"><a href="/whois/" onMouseOut="MM_swapImgRestore()"  onMouseOver="MM_swapImage('whois','','/imagenes/base3/whois_f2.gif',1);" ><img name="whois" src="/imagenes/base3/whois.gif" width="43" height="16" border="0" alt="Consulta nuestro Whois"></a></td>
    <td rowspan="2" bgcolor="#FFFFFF"><img name="slice_r6_c10" src="/imagenes/base3/slice_r6_c10.gif" width="8" height="16" border="0" alt="registro de dominios"></td>
    <td rowspan="2" colspan="8" bgcolor="#FFFFFF"><img name="Lineadeinfo" src="/imagenes/base3/spacer.gif" width="488" height="16" border="0" alt="registro de dominios"></td>
    <td rowspan="2" bgcolor="#FFFFFF"><img name="derecho" src="/imagenes/base3/derecho.gif" width="14" height="16" border="0" alt="registro de dominios"></td>
    <td><img src="/imagenes/base3/spacer.gif" width="1" height="12" border="0"></td>
  </tr>
  <tr> 
    <td><img src="/imagenes/base3/spacer.gif" width="1" height="4" border="0"></td>
  </tr>
</table><!-- #EndLibraryItem --><table bgcolor="#ffcc00" border="0" cellpadding="0" cellspacing="0" width="740" align="center">
  <!-- fwtable fwsrc="Nuevabase_izq_ok1.png" fwbase="nm2_base.gif" fwstyle="Dreamweaver" fwdocid = "1425088159" fwnested="0" -->
  <tr bgcolor="#FFFFFF"> 
    <td width="15"><img src="/imagenes/base2/slice_r4_c1.gif" width="15" height="1" border="0"></td>
    <td width="6"><img src="/imagenes/base2/spacer.gif" width="6" height="1" border="0"></td>
    <td width="8"><img src="/imagenes/base2/spacer.gif" width="8" height="1" border="0"></td>
    <td width="5"><img src="/imagenes/base2/spacer.gif" width="5" height="1" border="0"></td>
    <td width="4"><img src="/imagenes/base2/spacer.gif" width="4" height="1" border="0"></td>
    <td width="12"><img src="/imagenes/base2/spacer.gif" width="12" height="1" border="0"></td>
    <td width="9"><img src="/imagenes/base2/spacer.gif" width="9" height="1" border="0"></td>
    <td width="39"><img src="/imagenes/base2/spacer.gif" width="39" height="1" border="0"></td>
    <td width="9"><img src="/imagenes/base2/spacer.gif" width="9" height="1" border="0"></td>
    <td width="33"><img src="/imagenes/base2/spacer.gif" width="33" height="1" border="0"></td>
    <td width="10"><img src="/imagenes/base2/spacer.gif" width="10" height="1" border="0"></td>
    <td width="31"><img src="/imagenes/base2/spacer.gif" width="31" height="1" border="0"></td>
    <td width="120"><img src="/imagenes/base2/spacer.gif" width="120" height="1" border="0"></td>
    <td width="57"><img src="/imagenes/base2/spacer.gif" width="57" height="1" border="0"></td>
    <td width="15"><img src="/imagenes/base2/spacer.gif" width="15" height="1" border="0"></td>
    <td width="60"><img src="/imagenes/base2/spacer.gif" width="60" height="1" border="0"></td>
    <td width="12"><img src="/imagenes/base2/spacer.gif" width="12" height="1" border="0"></td>
    <td width="76"><img src="/imagenes/base2/spacer.gif" width="76" height="1" border="0"></td>
    <td width="25"><img src="/imagenes/base2/spacer.gif" width="25" height="1" border="0"></td>
    <td width="58"><img src="/imagenes/base2/spacer.gif" width="58" height="1" border="0"></td>
    <td width="10"><img src="/imagenes/base2/spacer.gif" width="10" height="1" border="0"></td>
    <td width="53"><img src="/imagenes/base2/spacer.gif" width="53" height="1" border="0"></td>
    <td width="18"><img src="/imagenes/base2/spacer.gif" width="18" height="1" border="0"></td>
    <td width="41"><img src="/imagenes/base2/spacer.gif" width="41" height="1" border="0"></td>
    <td width="14"><img src="/imagenes/base2/corteder.gif" width="14" height="1" border="0"></td>
    <td width="1"><img src="/imagenes/base2/spacer_naranja.gif" width="1" height="1" border="0"></td>
  </tr>
  <tr> 
    <td rowspan="3" height="150" bgcolor="#FFFFFF" background="/imagenes/base2/corteizq.gif" valign="bottom"><img name="esq_izq_abajo" src="/imagenes/base2/esq_izq_abajo.gif" width="15" height="21" border="0" alt="registro de dominios"></td>
    <td colspan="23" height="325" bgcolor="#FFFFFF" valign="top"><br>
	<!-- #BeginEditable "contenido" --> 
      <table width="710" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td width="180" valign="top"> <font face="Verdana, Arial, Helvetica, sans-serif" size="1"> 
            </font></td>
          <td width="10" valign="top"><font face="Verdana, Arial, Helvetica, sans-serif" size="1"><img src="/imagenes/base2/spacer.gif" width="10" height="8" border="0"></font></td>
          <td width="520" valign="top"><font face="Verdana, Arial, Helvetica, sans-serif" size="1">&nbsp;</font><font face="Verdana, Arial, Helvetica, sans-serif" size="1">
            <!--columna  -->
            </font> <br>
            <table width="520" border="0" cellspacing="0" cellpadding="0">
              <tr> 
                <td height="18"><img src="/imagenes/titular_re_do_es3.gif" width="520" height="32"></td>
              </tr>
            </table>
            <table border="0" width="520" cellpadding="0" cellspacing="0">
              <tr> 
                <td height="19">&nbsp; </td>
              </tr>
              <tr align="left"> 
                <td> 
                  <?
if ($Tipodedominio=="Pro") {
$paso4="final_es.php";
}
else {
$paso4="estandar_es.php";
}
?>
                  <font face="Verdana, Arial, Helvetica, sans-serif" size="2"><span class="body_11"><font size="1">DATOS 
                  DE CONTACTO.</font></span></font><br>
                  <br>
                  <form method="post" action="<?=$paso4 ?>" name="dominioses" onSubmit="compruebaentradas();return document.MM_returnValue">
                    <font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                    <input type="hidden" name="affiliate_id" value="<? echo $affiliate_id?>">
                    <input type="hidden" name="dominio" value="<? echo $dominio?>">
                    <input type="hidden" name="Organizacion" value="<? echo $Organizacion?>">
                    <input type="hidden" name="Formajuridica" value="<? echo $Formajuridica?>">
                    <input type="hidden" name="NIF" value="<? echo $NIF?>">
                    <input type="hidden" name="Fechaconstitucion" value="<? echo $Fechaconstitucion?>">
                    <input type="hidden" name="Domicilio" value="<? echo $Domicilio?>">
                    <input type="hidden" name="Municipio" value="<? echo $Municipio?>">
                    <input type="hidden" name="CP" value="<? echo $CP?>">
                    <input type="hidden" name="Provincia" value="<? echo $Provincia?>">
                    <input type="hidden" name="Marca" value="<? echo $Marca?>">
                    <input type="hidden" name="Numero" value="<? echo $Numero?>">
                    <input type="hidden" name="Fechaconcesion" value="<? echo $Fechaconcesion?>">
                    <input type="hidden" name="Tipodedominio" value="<?=$Tipodedominio ?>">
                    </font> 
                    <table width="100%" border="0" align="center">
                      <tr> 
                        <td colspan="2" valign="top" bgcolor="#000066" class="titu_secciones"><font color="#FFFFFF" face="Verdana, Arial, Helvetica, sans-serif" size="1"> 
                          <b>Persona de contacto Administrativo</b></font></td>
                      </tr>
                      <tr> 
                        <td class="td_form_titulo"> <font size="1" face="Verdana, Arial, Helvetica, sans-serif">NIC-HANDLE 
                          <br>
                          (Si lo posee, no es necesario <br>
                          que rellene los dem&aacute;s campos)</font> </td>
                        <td nowrap bgcolor="#CCCCCC" class="td_form_valor"> <font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                          <input type="text" name="NICadm" size="20" maxlength="20">
                          </font> </td>
                      </tr>
                      <tr> 
                        <td class="td_form_titulo"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Nombre 
                            y apellidos</font></div>
                        </td>
                        <td nowrap bgcolor="#CCCCCC" class="td_form_valor"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                            <input type="text" name="Nombreadm" size="40" maxlength="256">
                            </font></div>
                        </td>
                      </tr>
                      <tr> 
                        <td class="td_form_titulo"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Nombre 
                            Organizaci&oacute;n Completo</font></div>
                        </td>
                        <td nowrap bgcolor="#CCCCCC" class="td_form_valor"> 
                          <div align="left"> <font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                            <input type="text" name="Organizacionadm" size="20" maxlength="256">
                            <select name="Tipoadm" size="1">
                              <option value="S.An&oacute;nima" selected>S.An&oacute;nima</option>
                              <option value="S.Limitada">S.Limitada</option>
                              <option value="S.R.Limitada">S.R.Limitada</option>
                              <option value="S.Civil">S.Civil</option>
                              <option value="S. Cooperativa">S. Cooperativa</option>
                              <option value="S.Agr.Transformaci&oacute;n">S.Agr.Transformaci&oacute;n</option>
                              <option value="S.An&oacute;n.Laboral">S.An&oacute;n.Laboral</option>
                              <option value="S. Lab. Limitada">S. Lab. Limitada</option>
                              <option value="Sucursal en Espa&ntilde;a">Sucursal 
                              en Espa&ntilde;a</option>
                              <option value="C.Bienes">C.Bienes</option>
                              <option value="C.Propietarios">C.Propietarios</option>
                              <option value="Caja de Ahorros">Caja de Ahorros</option>
                              <option value="Fundaci&oacute;n">Fundaci&oacute;n</option>
                              <option value="Asoc.">Asoc.</option>
                              <option value="Asoc. Gremial">Asoc. Gremial</option>
                              <option value="Federaci&oacute;n">Federaci&oacute;n</option>
                              <option value="Partido Pol&iacute;tico">Partido 
                              Pol&iacute;tico</option>
                              <option value="Col. Profesional">Col. Profesional</option>
                              <option value="Inst. Religiosa">Inst. Religiosa</option>
                              <option value="Org. Aut&oacute;nomo no Estatal">Org. 
                              Aut&oacute;nomo no Estatal</option>
                              <option value="Org. Aut&oacute;nomo Estatal">Org. 
                              Aut&oacute;nomo Estatal</option>
                              <option value="Corporaci&oacute;n Local">Corporaci&oacute;n 
                              Local</option>
                              <option value="Org. Adm&oacute;n. del Estado">Org. 
                              Adm&oacute;n. del Estado</option>
                              <option value="Org. Adm&oacute;n. Auton&oacute;mica">Org. 
                              Adm&oacute;n. Auton&oacute;mica</option>
                              <option value="- ">- </option>
                            </select>
                            </font></div>
                        </td>
                      </tr>
                      <tr> 
                        <td class="td_form_titulo"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Nombre 
                            Departamento <br>
                            (si no hay d&eacute;jelo en blanco)</font></div>
                        </td>
                        <td nowrap bgcolor="#CCCCCC" class="td_form_valor"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                            <input type="text" name="Departamentoadm" size="20" maxlength="30">
                            </font></div>
                        </td>
                      </tr>
                      <tr> 
                        <td class="td_form_titulo"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Cargo/s 
                            <br>
                            (si hay varios separe con comas)</font></div>
                        </td>
                        <td nowrap bgcolor="#CCCCCC" class="td_form_valor"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                            <input type="text" name="Cargosadm" size="20" maxlength="30">
                            </font></div>
                        </td>
                      </tr>
                      <tr> 
                        <td class="td_form_titulo"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Direcci&oacute;n</font></div>
                        </td>
                        <td nowrap bgcolor="#CCCCCC" class="td_form_valor"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                            <input type="text" name="Direccionadm" size="40" maxlength="256">
                            </font></div>
                        </td>
                      </tr>
                      <tr> 
                        <td class="td_form_titulo"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Municipio</font></div>
                        </td>
                        <td nowrap bgcolor="#CCCCCC" class="td_form_valor"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                            <input type="text" name="Municipioadm" size="40" maxlength="50">
                            </font></div>
                        </td>
                      </tr>
                      <tr> 
                        <td class="td_form_titulo"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Cod. 
                            Postal</font></div>
                        </td>
                        <td nowrap bgcolor="#CCCCCC" class="td_form_valor"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">E 
                            -</font> <font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                            <input type="text" name="CPadm" size="10" maxlength="5">
                            </font></div>
                        </td>
                      </tr>
                      <tr> 
                        <td class="td_form_titulo"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                            Provincia</font></div>
                        </td>
                        <td nowrap bgcolor="#CCCCCC" class="td_form_valor"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                            <input type="text" name="Provinciaadm" size="40" maxlength="50">
                            </font></div>
                        </td>
                      </tr>
                      <tr> 
                        <td class="td_form_titulo"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                            Pa&iacute;s</font></div>
                        </td>
                        <td nowrap bgcolor="#CCCCCC" class="td_form_valor"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                            ESPA&Ntilde;A</font></div>
                        </td>
                      </tr>
                      <tr> 
                        <td class="td_form_titulo"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">E-mail</font></div>
                        </td>
                        <td nowrap bgcolor="#CCCCCC" class="td_form_valor"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                            <input type="text" name="Emailadm" size="40" maxlength="100">
                            </font></div>
                        </td>
                      </tr>
                      <tr> 
                        <td class="td_form_titulo"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Fax 
                            Formato Internacional.<br>
                            (Pais, Tel&eacute;fono)</font></div>
                        </td>
                        <td nowrap bgcolor="#CCCCCC" class="td_form_valor"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                            <input type="text" name="Faxpreadm" size="2" maxlength="2" value='34'>
                            <input type="text" name="Faxadm" size="12" maxlength="50">
                            (ej:34 914602891)</font></div>
                        </td>
                      </tr>
                      <tr> 
                        <td class="td_form_titulo"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Tel&eacute;fono 
                            Formato Internacional.<br>
                            (Pais, Tel&eacute;fono)</font></div>
                        </td>
                        <td nowrap bgcolor="#CCCCCC" class="td_form_valor"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                            <input type="text" name="Telpreadm" size="2" maxlength="2" value='34'>
                            <input type="text" name="Teladm" size="12" maxlength="50">
                            (ej:34 914602891)</font></div>
                        </td>
                      </tr>
                      <tr> 
                        <td colspan="2" valign="top">&nbsp;</td>
                      </tr>
                      <tr> 
                        <td colspan="2" valign="top" bgcolor="#000066" class="titu_secciones"> 
                          <p align="left"><font face="Verdana, Arial, Helvetica, sans-serif" size="1" color="#FFFFFF"><b>Persona 
                            de Contacto Facturaci&oacute;n</b></font></p>
                        </td>
                      </tr>
                      <tr> 
                        <td bgcolor="#FFFFFF" class="td_form_titulo"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">NIC-HANDLE 
                            <br>
                            (Si lo posee, no es necesario <br>
                            que rellene los dem&aacute;s campos)</font></div>
                        </td>
                        <td nowrap bgcolor="#FFCC00" class="td_form_valor"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                            <input type="text" name="NICfac" size="20" maxlength="20">
                            </font></div>
                        </td>
                      </tr>
                      <tr> 
                        <td bgcolor="#FFFFFF" class="td_form_titulo"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Nombre 
                            y apellidos</font></div>
                        </td>
                        <td nowrap bgcolor="#FFCC00" class="td_form_valor"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                            <input type="text" name="Nombrefac" size="40" maxlength="256">
                            </font></div>
                        </td>
                      </tr>
                      <tr> 
                        <td bgcolor="#FFFFFF" class="td_form_titulo"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Nombre 
                            Organizaci&oacute;n Completo</font></div>
                        </td>
                        <td nowrap bgcolor="#FFCC00" class="td_form_valor"> 
                          <div align="left"> <font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                            <input type="text" name="Organizacionfac" size="20" maxlength="256">
                            <select name="Tipofac" size="1">
                              <option value="S.An&oacute;nima" selected>S.An&oacute;nima</option>
                              <option value="S.Limitada">S.Limitada</option>
                              <option value="S.R.Limitada">S.R.Limitada</option>
                              <option value="S.Civil">S.Civil</option>
                              <option value="S. Cooperativa">S. Cooperativa</option>
                              <option value="S.Agr.Transformaci&oacute;n">S.Agr.Transformaci&oacute;n</option>
                              <option value="S.An&oacute;n.Laboral">S.An&oacute;n.Laboral</option>
                              <option value="S. Lab. Limitada">S. Lab. Limitada</option>
                              <option value="Sucursal en Espa&ntilde;a">Sucursal 
                              en Espa&ntilde;a</option>
                              <option value="C.Bienes">C.Bienes</option>
                              <option value="C.Propietarios">C.Propietarios</option>
                              <option value="Caja de Ahorros">Caja de Ahorros</option>
                              <option value="Fundaci&oacute;n">Fundaci&oacute;n</option>
                              <option value="Asoc.">Asoc.</option>
                              <option value="Asoc. Gremial">Asoc. Gremial</option>
                              <option value="Federaci&oacute;n">Federaci&oacute;n</option>
                              <option value="Partido Pol&iacute;tico">Partido 
                              Pol&iacute;tico</option>
                              <option value="Col. Profesional">Col. Profesional</option>
                              <option value="Inst. Religiosa">Inst. Religiosa</option>
                              <option value="Org. Aut&oacute;nomo no Estatal">Org. 
                              Aut&oacute;nomo no Estatal</option>
                              <option value="Org. Aut&oacute;nomo Estatal">Org. 
                              Aut&oacute;nomo Estatal</option>
                              <option value="Corporaci&oacute;n Local">Corporaci&oacute;n 
                              Local</option>
                              <option value="Org. Adm&oacute;n. del Estado">Org. 
                              Adm&oacute;n. del Estado</option>
                              <option value="Org. Adm&oacute;n. Auton&oacute;mica">Org. 
                              Adm&oacute;n. Auton&oacute;mica</option>
                              <option value="- ">- </option>
                            </select>
                            </font></div>
                        </td>
                      </tr>
                      <tr> 
                        <td bgcolor="#FFFFFF" class="td_form_titulo"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Nombre 
                            Departamento <br>
                            (si no hay d&eacute;jelo en blanco)</font></div>
                        </td>
                        <td nowrap bgcolor="#FFCC00" class="td_form_valor"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                            <input type="text" name="Departamentofac" size="20" maxlength="30">
                            </font></div>
                        </td>
                      </tr>
                      <tr> 
                        <td bgcolor="#FFFFFF" class="td_form_titulo"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Cargo/s 
                            <br>
                            (si hay varios separe con comas)</font></div>
                        </td>
                        <td nowrap bgcolor="#FFCC00" class="td_form_valor"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                            <input type="text" name="Cargosfac" size="20" maxlength="30">
                            </font></div>
                        </td>
                      </tr>
                      <tr> 
                        <td bgcolor="#FFFFFF" class="td_form_titulo"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Direcci&oacute;n</font></div>
                        </td>
                        <td nowrap bgcolor="#FFCC00" class="td_form_valor"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                            <input type="text" name="Direccionfac" size="40" maxlength="256">
                            </font></div>
                        </td>
                      </tr>
                      <tr> 
                        <td bgcolor="#FFFFFF" class="td_form_titulo"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Municipio</font></div>
                        </td>
                        <td nowrap bgcolor="#FFCC00" class="td_form_valor"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                            <input type="text" name="Municipiofac" size="40" maxlength="50">
                            </font></div>
                        </td>
                      </tr>
                      <tr> 
                        <td bgcolor="#FFFFFF" class="td_form_titulo"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Cod. 
                            Postal <br>
                            (Pa&iacute;s-</font> <font size="1" face="Verdana, Arial, Helvetica, sans-serif">C&oacute;digo)</font></div>
                        </td>
                        <td nowrap bgcolor="#FFCC00" class="td_form_valor"> 
                          <div align="left"> <font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                            <input type="text" name="CPfac" size="10" maxlength="10">
                            (ej: FR-12345)</font></div>
                        </td>
                      </tr>
                      <tr> 
                        <td bgcolor="#FFFFFF" class="td_form_titulo"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Provincia</font></div>
                        </td>
                        <td nowrap bgcolor="#FFCC00" class="td_form_valor"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                            <input type="text" name="Provinciafac" size="40" maxlength="50">
                            </font></div>
                        </td>
                      </tr>
                      <tr> 
                        <td bgcolor="#FFFFFF" class="td_form_titulo"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Pa&iacute;s 
                            (en ingl&eacute;s)</font></div>
                        </td>
                        <td nowrap bgcolor="#FFCC00" class="td_form_valor"> 
                          <div align="left"> <font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                            <select name="Paisfac">
                              <option></option>
                              <option> AFGHANISTAN </option>
                              <option> ALBANIA </option>
                              <option> ALGERIA </option>
                              <option> AMERICAN SAMOA </option>
                              <option> ANDORRA </option>
                              <option> ANGOLA </option>
                              <option> ANGUILLA </option>
                              <option> ANTIGUA </option>
                              <option> ARGENTINA </option>
                              <option> ARMENIA </option>
                              <option> ARUBA </option>
                              <option> AUSTRALIA </option>
                              <option> AUSTRIA </option>
                              <option> AZERBAIJAN </option>
                              <option> BAHAMAS </option>
                              <option> BAHRAIN </option>
                              <option> BANGLADESH </option>
                              <option> BARBADOS </option>
                              <option> BELARUS </option>
                              <option> BELGIUM </option>
                              <option> BELIZE </option>
                              <option> BENIN </option>
                              <option> BERMUDA </option>
                              <option> BHUTAN </option>
                              <option> BOLIVIA </option>
                              <option> BOSNIA </option>
                              <option> BOTSWANA </option>
                              <option> BRAZIL </option>
                              <option> BRITISH VIRGIN ISLANDS </option>
                              <option> BRUNEI </option>
                              <option> BULGARIA </option>
                              <option> BURKINA FASO </option>
                              <option> BURMA </option>
                              <option> BURNEI </option>
                              <option> BURUNDI </option>
                              <option> CAMBODIA </option>
                              <option> CAMEROON </option>
                              <option> CANADA </option>
                              <option> CANARY ISLANDS </option>
                              <option> CAPE VERDE </option>
                              <option> CAYMAN ISLANDS </option>
                              <option> CHAD </option>
                              <option> CHILE </option>
                              <option> CHINA, PEOP. REP OF </option>
                              <option> COLOMBIA </option>
                              <option> COMOROS </option>
                              <option> CONGO, PEOP REP OF </option>
                              <option> COOK ISLANDS </option>
                              <option> COSTA RICA </option>
                              <option> CROATIA </option>
                              <option> CUBA </option>
                              <option> CYPRUS </option>
                              <option> CZECH REPUBLIC </option>
                              <option> DENMARK </option>
                              <option> DJIBOUTI </option>
                              <option> DOMINICA </option>
                              <option> DOMINICAN REPUBLIC </option>
                              <option> ECUADOR </option>
                              <option> EGYPT </option>
                              <option> EL SALVADOR </option>
                              <option> EQUATORIAL GUINEA </option>
                              <option> ESTONIA </option>
                              <option> ETHIOPIA </option>
                              <option> FAEROE ISLANDS </option>
                              <option> FALKLAND ISLANDS </option>
                              <option> FIJI </option>
                              <option> FINLAND </option>
                              <option> FRANCE </option>
                              <option> FRENCH GUIANA </option>
                              <option> FRENCH POLYNESIA </option>
                              <option> GABON </option>
                              <option> GAMBIA </option>
                              <option> GEORGIA </option>
                              <option> GERMANY </option>
                              <option> GHANA </option>
                              <option> GIBRALTAR </option>
                              <option> GREECE </option>
                              <option> GREENLAND </option>
                              <option> GRENADA </option>
                              <option> GUADELOUPE </option>
                              <option> GUAM </option>
                              <option> GUATEMALA </option>
                              <option> GUERNSEY ISLE </option>
                              <option> GUINEA </option>
                              <option> GUINEA-BISSAU </option>
                              <option> GUYANA </option>
                              <option> HAITI </option>
                              <option> HOLLAND </option>
                              <option> HONDURAS </option>
                              <option> HONG KONG </option>
                              <option> HUNGARY </option>
                              <option> ICELAND </option>
                              <option> INDIA </option>
                              <option> INDONESIA </option>
                              <option> IRAN </option>
                              <option> IRAQ </option>
                              <option> IRELAND </option>
                              <option> IRELAND, REP OF </option>
                              <option> ISRAEL </option>
                              <option> ITALY </option>
                              <option> IVORY COAST </option>
                              <option> JAMAICA </option>
                              <option> JAPAN </option>
                              <option> JORDAN </option>
                              <option> KAMPUCHEA (CAMBODIA) </option>
                              <option> KAZAKHSTAN </option>
                              <option> KENYA </option>
                              <option> KIRIBATI </option>
                              <option> KOREA, REP OF </option>
                              <option> KUWAIT </option>
                              <option> KYRGYZSTAN </option>
                              <option> LA REUNION </option>
                              <option> LAOS </option>
                              <option> LATVIA </option>
                              <option> LEBANON </option>
                              <option> LESOTHO </option>
                              <option> LIBERIA </option>
                              <option> LIBYA </option>
                              <option> LIECHTENSTEIN </option>
                              <option> LITHUANIA </option>
                              <option> LUXEMBOURG </option>
                              <option> MACAO </option>
                              <option> MACEDONIA </option>
                              <option> MADAGASCAR </option>
                              <option> MALAWI </option>
                              <option> MALAYSIA </option>
                              <option> MALDIVES </option>
                              <option> MALI </option>
                              <option> MALTA </option>
                              <option> MAURITANIA </option>
                              <option> MAURITIUS </option>
                              <option> MAYOTTE </option>
                              <option> MEXICO </option>
                              <option> MICRONESIA </option>
                              <option> MONACO </option>
                              <option> MONGOLIA </option>
                              <option> MONTENEGRO </option>
                              <option> MONTSERRAT </option>
                              <option> MOROCCO </option>
                              <option> MOZAMBIQUE </option>
                              <option> MULDOVIA </option>
                              <option> NAMIBIA </option>
                              <option> NAURU </option>
                              <option> NEPAL </option>
                              <option> NETHERLANDS </option>
                              <option> NETHERLANDS ANT. </option>
                              <option> NEW CALEDONIA </option>
                              <option> NEW HEBRIDES </option>
                              <option> NEW ZEALAND </option>
                              <option> NICARAGUA </option>
                              <option> NIGER </option>
                              <option> NIGERIA </option>
                              <option> NORWAY </option>
                              <option> OMAN </option>
                              <option> PAKISTAN </option>
                              <option> PANAMA </option>
                              <option> PAPUA NEW GUINEA </option>
                              <option> PARAGUAY </option>
                              <option> PERU </option>
                              <option> PHILIPPINES </option>
                              <option> POLAND </option>
                              <option> PORTUGAL </option>
                              <option> PUERTO RICO </option>
                              <option> QATAR </option>
                              <option> ROMANIA </option>
                              <option> RUSSIA </option>
                              <option> RWANDA </option>
                              <option> SAMOA </option>
                              <option> SAN MARINO </option>
                              <option> SAO TOME &AMP; PRINCIPE </option>
                              <option> SAUDI ARABIA </option>
                              <option> SCOTLAND, UK </option>
                              <option> SENEGAL </option>
                              <option> SERBIA </option>
                              <option> SEYCHELLES </option>
                              <option> SIERRA LEONE </option>
                              <option> SINGAPORE </option>
                              <option> SLOVAK REPUBLIC </option>
                              <option> SLOVENIA </option>
                              <option> SOLOMON ISLANDS </option>
                              <option> SOMALIA </option>
                              <option> SOUTH AFRICA </option>
                              <option selected> SPAIN </option>
                              <option> SRI LANKA </option>
                              <option> ST. HELENA </option>
                              <option> ST. KITTS - NEVIS </option>
                              <option> ST. LUCIA </option>
                              <option> ST. PIERRE &AMP; MIQUELO </option>
                              <option> ST. VINCENT </option>
                              <option> SURINAME </option>
                              <option> SWAZILAND </option>
                              <option> SWEDEN </option>
                              <option> SWITZERLAND </option>
                              <option> SYRIA </option>
                              <option> TAIWAN </option>
                              <option> TAJIKSTAN </option>
                              <option> TANZANIA </option>
                              <option> THAILAND </option>
                              <option> TOGO </option>
                              <option> TONGA </option>
                              <option> TRINIDAD AND TOBAGO </option>
                              <option> TUNISIA </option>
                              <option> TURKEY </option>
                              <option> TURKMENISTAN </option>
                              <option> TURKS AND CAICOS </option>
                              <option> UGANDA </option>
                              <option> UKRAINE </option>
                              <option> UNITED ARAB EMIRATES </option>
                              <option> UNITED KINGDOM </option>
                              <option> URUGUAY </option>
                              <option> USA </option>
                              <option> UZBEKISTAN </option>
                              <option> VANUATU </option>
                              <option> VATICAN CITY STATE </option>
                              <option> VENEZUELA </option>
                              <option> VIETNAM </option>
                              <option> VIRGIN ISLANDS (BR.) </option>
                              <option> WALLIS &AMP; FORTUNA IS. </option>
                              <option> YEMEN, PEOP. REP. OF </option>
                              <option> YUGOSLAVIA </option>
                              <option> ZAIRE </option>
                              <option> ZAMBIA </option>
                              <option> ZIMBABWE </option>
                            </select>
                            </font></div>
                        </td>
                      </tr>
                      <tr> 
                        <td bgcolor="#FFFFFF" class="td_form_titulo"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">E-mail</font></div>
                        </td>
                        <td nowrap bgcolor="#FFCC00" class="td_form_valor"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                            <input type="text" name="Emailfac" size="40" maxlength="100">
                            </font></div>
                        </td>
                      </tr>
                      <tr> 
                        <td bgcolor="#FFFFFF" class="td_form_titulo"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Fax 
                            Formato Internacional. <br>
                            (Pa&iacute;s, Tel&eacute;fono)</font></div>
                        </td>
                        <td nowrap bgcolor="#FFCC00" class="td_form_valor"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                            <input type="text" name="faxprefac" size="2" maxlength="2" value='34'>
                            <input type="text" name="Faxfac" size="12" maxlength="50">
                            &nbsp;(ej:34 914602891)</font></div>
                        </td>
                      </tr>
                      <tr> 
                        <td bgcolor="#FFFFFF" class="td_form_titulo"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">Tel&eacute;fono 
                            Formato Internacional.<br>
                            (Pa&iacute;s, Tel&eacute;fono)</font></div>
                        </td>
                        <td nowrap bgcolor="#FFCC00" class="td_form_valor"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                            <input type="text" name="Telprefac" size="2" maxlength="2" value='34'>
                            <input type="text" name="Telfac" size="12" maxlength="50">
                            &nbsp;(ej:34 914602891)</font></div>
                        </td>
                      </tr>
                      <tr> 
                        <td bgcolor="#FFFFFF" class="td_form_titulo"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif">N.I.F. 
                            <br>
                            (Organizaci&oacute;n persona facturaci&oacute;n)</font></div>
                        </td>
                        <td nowrap bgcolor="#FFCC00" class="td_form_valor"> 
                          <div align="left"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                            <input type="text" name="NIFfac" size="14" maxlength="16">
                            (Ej.: A60689551)</font></div>
                        </td>
                      </tr>
                      <tr align="center"> 
                        <td colspan="2"> 
                          <hr size="1" color="orange">
                          <center>
                            <input type="image" border="0" name="imageField2" src="../imagenes/continuar.gif">
                          </center>
                        </td>
                      </tr>
                    </table>
                  </form>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
      <p>&nbsp;</p>
      <!-- #EndEditable --> </td>
    <td rowspan="3" height="150" bgcolor="#FFFFFF" background="/imagenes/base2/corteder.gif" valign="bottom"><img name="esq_der_abajo" src="/imagenes/base2/esq_der_abajo.gif" width="14" height="21" border="0" alt="registro de dominios"></td>
    <td width="1" height="150"><img src="/imagenes/base2/spacer.gif" width="1" height="8" border="0"></td>
  </tr>
  <tr> 
    <td colspan="23" bgcolor="#FFFFFF" valign="bottom"><!-- #BeginEditable "Pie de p%EF%BF%BDgina" -->&nbsp;<!-- #EndEditable --><!-- #BeginLibraryItem "/Library/nm2_pie_generico.lbi" --><table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
  <tr> 
    <td valign="middle"><p class="mini">Tus <a href="http://www.golfinspain.com/esp/?utm_source=nombremania&utm_medium=link&utm_content=footer&utm_campaign=sitios">viajes de golf</a> en GolfinSpain.com · <a href="http://alsur.es">hecho alsur </a></p></td>
    <td valign="middle" align="right">
      <table border="0" cellspacing="0" cellpadding="0" class="mini">
        <tr> 
          <td align="right"> <font face="Verdana, Arial" size="1" color="#666666"><span class="mini">[<a class="mini"  href="/registrar.php">registrar</a>] 
            [<a href="/trasladar.php">trasladar</a>] [<a href="http://admin.nombremania.com">administrar</a>] 
            [<a href="/ayuda/">ayuda</a>]</span></font></td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-32785580-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script><!-- #EndLibraryItem --></td>
    <td width="1"><img src="/imagenes/base2/spacer.gif" width="1" height="13" border="0"></td>
  </tr>
  <tr> 
    <td width="6"><img name="abajo1" src="/imagenes/base2/abajo1.gif" width="6" height="8" border="0" alt="registro de dominios"></td>
    <td width="8"><img name="abajo" src="/imagenes/base2/abajo.gif" width="8" height="8" border="0" alt="registro de dominios"></td>
    <td colspan="21"><img name="ko_abajo" src="/imagenes/base2/ko_abajo.gif" width="697" height="8" border="0" alt="registro de dominios"></td>
    <td width="1"><img src="/imagenes/base2/spacer.gif" width="1" height="8" border="0"></td>
  </tr>
</table>
</body>
<!-- #EndTemplate --></HTML>
